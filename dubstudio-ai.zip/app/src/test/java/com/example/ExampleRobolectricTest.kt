package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.SubtitleSegment
import com.example.data.model.VoiceOption
import com.example.data.network.TranslationService
import com.example.data.video.VideoExportService
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun readStringFromContext() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("DubStudio AI", appName)
    }

    @Test
    fun testTextSanitizationForTts() {
        val raw = "【爆笑】今天去吃火锅！#美食 #vlog 😊"
        val cleaned = TranslationService.sanitizeForTts(raw)
        // Should strip hashtag, bracket, and emojis
        assertTrue(!cleaned.contains("【"))
        assertTrue(!cleaned.contains("】"))
        assertTrue(!cleaned.contains("#美食"))
        assertTrue(!cleaned.contains("😊"))
    }

    @Test
    fun testSrtGeneration() {
        val segments = listOf(
            SubtitleSegment(
                id = 1,
                projectId = "test_proj",
                indexNumber = 1,
                startTimeMs = 1000,
                endTimeMs = 3500,
                originalChinese = "你好",
                vietnameseText = "Xin chào"
            )
        )
        val srt = VideoExportService.generateSrtContent(segments)
        assertTrue(srt.contains("1"))
        assertTrue(srt.contains("00:00:01,000 --> 00:00:03,500"))
        assertTrue(srt.contains("Xin chào"))
    }

    @Test
    fun testVoiceOptionsConfigured() {
        val hoaiMy = VoiceOption.findById("vi-VN-HoaiMyNeural")
        assertNotNull(hoaiMy)
        assertEquals("Hoài Mỹ", hoaiMy.name)
        assertEquals("Nữ", hoaiMy.gender)

        val namMinh = VoiceOption.findById("vi-VN-NamMinhNeural")
        assertNotNull(namMinh)
        assertEquals("Nam Minh", namMinh.name)
        assertEquals("Nam", namMinh.gender)
    }

    @Test
    fun testFFmpegOptionsConfiguration() {
        val options = com.example.data.video.FFmpegOptions(
            preset = "ultrafast",
            threads = 4,
            bitrateKbps = 3000
        )
        assertEquals("ultrafast", options.preset)
        assertEquals(4, options.threads)
        assertEquals(3000, options.bitrateKbps)
        assertEquals("libx264", options.videoCodec)
    }
}
