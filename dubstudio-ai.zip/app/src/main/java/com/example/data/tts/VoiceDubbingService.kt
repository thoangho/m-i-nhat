package com.example.data.tts

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import com.example.data.model.DubbingConfig
import com.example.data.network.TranslationService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale
import java.util.UUID
import kotlin.coroutines.resume

class VoiceDubbingService(private val context: Context) {
    private val TAG = "VoiceDubbingService"

    private var tts: TextToSpeech? = null
    private var isInitialized = false
    private var isVietnameseSupported = false

    var onDuckingChange: ((isDucking: Boolean) -> Unit)? = null

    init {
        initTts()
    }

    private fun initTts() {
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val viLocale = Locale.forLanguageTag("vi-VN")
                val result = tts?.setLanguage(viLocale)
                isVietnameseSupported = (result != TextToSpeech.LANG_MISSING_DATA &&
                        result != TextToSpeech.LANG_NOT_SUPPORTED)
                isInitialized = true
                Log.d(TAG, "TTS initialized. Vietnamese supported: $isVietnameseSupported")
            } else {
                Log.e(TAG, "TTS initialization failed with code $status")
            }
        }

        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                onDuckingChange?.invoke(true)
            }

            override fun onDone(utteranceId: String?) {
                onDuckingChange?.invoke(false)
            }

            override fun onError(utteranceId: String?) {
                onDuckingChange?.invoke(false)
            }
        })
    }

    /**
     * Configure Voice Tone & Gender matching Hoài Mỹ or Nam Minh
     */
    fun applyVoiceConfig(config: DubbingConfig) {
        val engine = tts ?: return

        // Pitch & Rate tuning
        if (config.voiceId.contains("NamMinh", ignoreCase = true) || config.isMale) {
            // Nam Minh: Deeper tone, clear, punchy
            engine.setPitch(0.85f * config.pitch)
            engine.setSpeechRate(1.0f * config.speechRate)
        } else {
            // Hoài Mỹ: Smooth, slightly higher pitch, expressive
            engine.setPitch(1.15f * config.pitch)
            engine.setSpeechRate(1.05f * config.speechRate)
        }
    }

    /**
     * Preview single sentence aloud
     */
    fun speakText(text: String, config: DubbingConfig) {
        val sanitized = TranslationService.sanitizeForTts(text)
        if (sanitized.isBlank()) return

        applyVoiceConfig(config)
        val params = Bundle().apply {
            putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, config.dubVoiceVolume)
        }
        tts?.speak(sanitized, TextToSpeech.QUEUE_FLUSH, params, "preview_${UUID.randomUUID()}")
    }

    fun stopSpeaking() {
        tts?.stop()
        onDuckingChange?.invoke(false)
    }

    /**
     * Synthesizes audio to an actual file on disk for a subtitle segment
     * Performs sanitization, retry up to 3 times, and returns file path or null
     */
    suspend fun synthesizeSegmentToFile(
        text: String,
        config: DubbingConfig,
        segmentId: Long
    ): File? = withContext(Dispatchers.IO) {
        val sanitized = TranslationService.sanitizeForTts(text)
        if (sanitized.isBlank()) return@withContext null

        val cacheDir = File(context.cacheDir, "dubbing_audio")
        if (!cacheDir.exists()) cacheDir.mkdirs()

        val outputFile = File(cacheDir, "dub_seg_${segmentId}_${config.voiceId}.wav")
        if (outputFile.exists() && outputFile.length() > 0) {
            // Cached file already exists and valid
            return@withContext outputFile
        }

        // Retry mechanism up to 3 times
        for (attempt in 1..3) {
            val success = synthesizeToFileInternal(sanitized, config, outputFile)
            if (success && outputFile.exists() && outputFile.length() > 0) {
                return@withContext outputFile
            }
            delay(300L * attempt)
        }
        null
    }

    private suspend fun synthesizeToFileInternal(
        text: String,
        config: DubbingConfig,
        outputFile: File
    ): Boolean = suspendCancellableCoroutine { continuation ->
        val engine = tts
        if (engine == null || !isInitialized) {
            continuation.resume(false)
            return@suspendCancellableCoroutine
        }

        applyVoiceConfig(config)
        val utteranceId = "synth_${System.currentTimeMillis()}"

        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}

            override fun onDone(id: String?) {
                if (id == utteranceId && continuation.isActive) {
                    continuation.resume(true)
                }
            }

            override fun onError(id: String?) {
                if (id == utteranceId && continuation.isActive) {
                    continuation.resume(false)
                }
            }
        })

        val params = Bundle().apply {
            putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, config.dubVoiceVolume)
        }

        val result = engine.synthesizeToFile(text, params, outputFile, utteranceId)
        if (result != TextToSpeech.SUCCESS) {
            if (continuation.isActive) continuation.resume(false)
        }
    }

    /**
     * Garbage collection & cache cleanup: deletes all temp dubbing files
     */
    fun clearTempAudioFiles() {
        try {
            val cacheDir = File(context.cacheDir, "dubbing_audio")
            if (cacheDir.exists()) {
                cacheDir.listFiles()?.forEach { it.delete() }
            }
            Log.d(TAG, "Temp audio files cleared.")
        } catch (e: Exception) {
            Log.w(TAG, "Error clearing temp audio files: ${e.message}")
        }
    }

    fun release() {
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
