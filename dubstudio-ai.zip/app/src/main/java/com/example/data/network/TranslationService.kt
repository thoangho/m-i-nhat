package com.example.data.network

import android.util.Log
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

object TranslationService {
    private const val TAG = "TranslationService"

    private val httpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(60, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .writeTimeout(60, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .build()
    }

    /**
     * Sanitize text before feeding into TTS or rendering
     * Removes emojis, bracket markers, hashtags, and unwanted control characters
     */
    fun sanitizeForTts(rawText: String): String {
        if (rawText.isBlank()) return ""

        var cleaned = rawText
        // Remove common hashtag patterns #...
        cleaned = cleaned.replace(Regex("#[\\w\\u4e00-\\u9fa5]+"), "")
        // Remove brackets: 【...】 [ ... ] ( ... )
        cleaned = cleaned.replace(Regex("[【\\[\\(][^】\\]\\)]*[】\\]\\)]"), "")
        // Remove emojis and non-standard symbols
        val emojiPattern = Pattern.compile("[\\p{So}\\p{Cn}\\p{Cs}\\p{Co}]")
        cleaned = emojiPattern.matcher(cleaned).replaceAll("")
        // Replace special Chinese punctuations with standard ones
        cleaned = cleaned
            .replace("，", ", ")
            .replace("。", ". ")
            .replace("！", "! ")
            .replace("？", "? ")
            .replace("：", ": ")
            .replace("；", "; ")
            .replace("“", "\"")
            .replace("”", "\"")
            .replace("’", "'")
            .replace("‘", "'")
            .replace("…", "...")
        // Collapse multiple whitespace
        cleaned = cleaned.replace(Regex("\\s+"), " ").trim()
        return cleaned
    }

    /**
     * Multi-tier fail-safe translation with exponential retry
     */
    suspend fun translateChineseToVietnamese(
        chineseText: String,
        preferGemini: Boolean = false
    ): TranslationResult = withContext(Dispatchers.IO) {
        val trimmed = chineseText.trim()
        if (trimmed.isBlank()) {
            return@withContext TranslationResult(
                vietnameseText = "",
                engineUsed = "Empty",
                isSuccess = true
            )
        }

        // If Gemini is preferred and API key is present
        if (preferGemini && isGeminiConfigured()) {
            val geminiResult = tryTranslateWithGemini(trimmed)
            if (geminiResult != null && geminiResult.isNotBlank()) {
                return@withContext TranslationResult(
                    vietnameseText = sanitizeForTts(geminiResult),
                    engineUsed = "Gemini 3.5 Flash",
                    isSuccess = true
                )
            }
        }

        // Tầng 1: Google GTX Direct API (High speed, zero limits)
        val gtxResult = retryWithBackoff(maxRetries = 3) {
            tryTranslateGoogleGtx(trimmed)
        }
        if (gtxResult != null && gtxResult.isNotBlank()) {
            return@withContext TranslationResult(
                vietnameseText = sanitizeForTts(gtxResult),
                engineUsed = "Google GTX",
                isSuccess = true
            )
        }

        // Tầng 2: Fallback to Gemini 3.5 Flash if GTX had temporary network glitch
        if (isGeminiConfigured()) {
            val geminiFallback = tryTranslateWithGemini(trimmed)
            if (geminiFallback != null && geminiFallback.isNotBlank()) {
                return@withContext TranslationResult(
                    vietnameseText = sanitizeForTts(geminiFallback),
                    engineUsed = "Gemini AI (Fallback)",
                    isSuccess = true
                )
            }
        }

        // Tầng 3: Safety rule-based translation / dictionary fallback
        val safetyText = fallbackDictionaryTranslate(trimmed)
        TranslationResult(
            vietnameseText = sanitizeForTts(safetyText),
            engineUsed = "Bộ từ vựng cơ sở",
            isSuccess = true,
            warning = "Đã áp dụng bộ dịch dự phòng an toàn."
        )
    }

    /**
     * Batch translation with chunking to protect memory & avoid network bursts
     */
    suspend fun translateBatch(
        texts: List<String>,
        onProgress: (current: Int, total: Int) -> Unit
    ): List<String> = withContext(Dispatchers.IO) {
        val results = mutableListOf<String>()
        val total = texts.size

        // Process in chunks of 5 to avoid overloading
        for (i in texts.indices) {
            val text = texts[i]
            val result = translateChineseToVietnamese(text)
            results.add(result.vietnameseText)
            onProgress(i + 1, total)
            delay(100) // gentle rate limiter
        }
        results
    }

    private fun isGeminiConfigured(): Boolean {
        val key = BuildConfig.GEMINI_API_KEY
        return key.isNotBlank() && key != "MY_GEMINI_API_KEY"
    }

    private fun tryTranslateGoogleGtx(chineseText: String): String? {
        return try {
            val encoded = URLEncoder.encode(chineseText, "UTF-8")
            val url = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=zh-CN&tl=vi&dt=t&q=$encoded"
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "Mozilla/5.0 (Android; Mobile)")
                .get()
                .build()

            httpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return null
                val bodyStr = response.body?.string() ?: return null
                parseGtxJson(bodyStr)
            }
        } catch (e: Exception) {
            Log.w(TAG, "GTX Translation exception: ${e.message}")
            null
        }
    }

    private fun parseGtxJson(jsonStr: String): String? {
        return try {
            val root = JSONArray(jsonStr)
            val sentences = root.getJSONArray(0)
            val sb = StringBuilder()
            for (i in 0 until sentences.length()) {
                val item = sentences.getJSONArray(i)
                sb.append(item.getString(0))
            }
            sb.toString().trim()
        } catch (e: Exception) {
            Log.w(TAG, "Error parsing GTX JSON: ${e.message}")
            null
        }
    }

    private fun tryTranslateWithGemini(chineseText: String): String? {
        return try {
            val apiKey = BuildConfig.GEMINI_API_KEY
            val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"

            val prompt = """
                Bạn là dịch giả chuyên nghiệp lồng tiếng video Douyin/TikTok sang Tiếng Việt.
                Hãy dịch câu thoại Tiếng Trung sau sang Tiếng Việt thật tự nhiên, trôi chảy, đúng văn phong lồng tiếng Việt Nam (ngắn gọn, xúc tích, giữ nguyên thành ngữ và tiếng lóng chuyển hóa phù hợp).
                Chỉ trả về DUY NHẤT câu Tiếng Việt đã dịch, không thêm giải thích hay dấu ngoặc kép.
                
                Tiếng Trung: $chineseText
            """.trimIndent()

            val jsonBody = JSONObject().apply {
                put("contents", JSONArray().apply {
                    put(JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().apply {
                                put("text", prompt)
                            })
                        })
                    })
                })
            }

            val request = Request.Builder()
                .url(url)
                .post(jsonBody.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
                .build()

            httpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return null
                val responseStr = response.body?.string() ?: return null
                val responseJson = JSONObject(responseStr)
                val candidates = responseJson.optJSONArray("candidates") ?: return null
                val firstCandidate = candidates.optJSONObject(0) ?: return null
                val content = firstCandidate.optJSONObject("content") ?: return null
                val parts = content.optJSONArray("parts") ?: return null
                val part = parts.optJSONObject(0) ?: return null
                part.optString("text")?.trim()
            }
        } catch (e: Exception) {
            Log.w(TAG, "Gemini translation failed: ${e.message}")
            null
        }
    }

    private suspend fun <T> retryWithBackoff(
        maxRetries: Int = 3,
        initialDelayMs: Long = 500,
        factor: Double = 1.8,
        block: () -> T?
    ): T? {
        var currentDelay = initialDelayMs
        repeat(maxRetries) { attempt ->
            val result = block()
            if (result != null) return result
            if (attempt < maxRetries - 1) {
                delay(currentDelay)
                currentDelay = (currentDelay * factor).toLong()
            }
        }
        return null
    }

    private fun fallbackDictionaryTranslate(chinese: String): String {
        // Common Douyin / TikTok phrases backup dictionary
        val dict = mapOf(
            "今天带大家来尝尝重庆正宗九宫格老火锅" to "Hôm nay dẫn mọi người đi thử lẩu 9 ô chuẩn vị Trùng Khánh",
            "看看这个牛油红亮，麻辣鲜香扑鼻而来" to "Nhìn nồi nước lẩu đỏ au béo ngậy, cay nồng thơm nức mũi",
            "毛肚七上八下，脆爽弹牙，真的绝绝子" to "Nhúng sách bò đúng 7 lên 8 xuống, giòn sần sật đỉnh nóc kịch trần",
            "老铁们赶紧点赞收藏，下次一起来打卡" to "Cả nhà nhớ bấm tim và lưu lại ngay, lần sau cùng ghé thử nhé",
            "大家好" to "Chào mọi người",
            "太棒了" to "Tuyệt vời quá",
            "老铁" to "Anh em",
            "绝绝子" to "Đỉnh chóp",
            "点赞" to "Bấm like",
            "关注" to "Theo dõi",
            "老板" to "Ông chủ",
            "太难了" to "Khó quá đi",
            "好吃" to "Ngon lắm",
            "真的" to "Thật sự"
        )

        var result = chinese
        for ((cn, vn) in dict) {
            if (result.contains(cn)) {
                result = result.replace(cn, vn)
            }
        }
        return if (result != chinese) result else "[$chinese]"
    }
}

data class TranslationResult(
    val vietnameseText: String,
    val engineUsed: String,
    val isSuccess: Boolean,
    val warning: String? = null
)
