package com.example.data.video

import android.content.Context
import com.example.data.model.SampleVideoItem
import com.example.data.model.SubtitleSegment
import com.example.data.model.VideoProject
import java.io.File
import java.io.FileOutputStream

object SampleVideoHelper {
    /**
     * Ensures each sample has an associated local video URI
     */
    fun getOrCreateSampleVideoUri(context: Context, sample: SampleVideoItem): String {
        val samplesDir = File(context.cacheDir, "sample_videos")
        if (!samplesDir.exists()) samplesDir.mkdirs()

        val sampleFile = File(samplesDir, "${sample.id}.mp4")
        if (!sampleFile.exists()) {
            // Write a lightweight valid MP4 container so media players/retrievers recognize it
            FileOutputStream(sampleFile).use { fos ->
                val ftyp = byteArrayOf(
                    0x00, 0x00, 0x00, 0x18,
                    'f'.code.toByte(), 't'.code.toByte(), 'y'.code.toByte(), 'p'.code.toByte(),
                    'm'.code.toByte(), 'p'.code.toByte(), '4'.code.toByte(), '2'.code.toByte(),
                    0x00, 0x00, 0x00, 0x00,
                    'm'.code.toByte(), 'p'.code.toByte(), '4'.code.toByte(), '2'.code.toByte(),
                    'i'.code.toByte(), 's'.code.toByte(), 'o'.code.toByte(), 'm'.code.toByte()
                )
                fos.write(ftyp)
            }
        }
        return sampleFile.absolutePath
    }

    fun createProjectFromSample(context: Context, sample: SampleVideoItem): Pair<VideoProject, List<SubtitleSegment>> {
        val uri = getOrCreateSampleVideoUri(context, sample)
        val project = VideoProject(
            id = sample.id,
            title = sample.title,
            videoUri = uri,
            durationMs = sample.durationSeconds * 1000L,
            aspectRatio = sample.aspectRatio,
            isSample = true
        )
        val segments = sample.initialSegments.mapIndexed { index, seed ->
            SubtitleSegment(
                projectId = sample.id,
                indexNumber = index + 1,
                startTimeMs = seed.startMs,
                endTimeMs = seed.endMs,
                originalChinese = seed.chinese,
                vietnameseText = seed.vietnamese
            )
        }
        return Pair(project, segments)
    }
}
