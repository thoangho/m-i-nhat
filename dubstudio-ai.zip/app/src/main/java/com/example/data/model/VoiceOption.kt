package com.example.data.model

data class VoiceOption(
    val id: String,
    val name: String,
    val region: String,
    val gender: String,
    val description: String,
    val avatarEmoji: String,
    val isDefault: Boolean = false
) {
    companion object {
        val ALL_VOICES = listOf(
            VoiceOption(
                id = "vi-VN-HoaiMyNeural",
                name = "Hoài Mỹ",
                region = "Miền Bắc",
                gender = "Nữ",
                description = "Giọng truyền cảm, mượt mà (kể chuyện, tin tức, review)",
                avatarEmoji = "👩",
                isDefault = true
            ),
            VoiceOption(
                id = "vi-VN-NamMinhNeural",
                name = "Nam Minh",
                region = "Miền Bắc",
                gender = "Nam",
                description = "Giọng rõ ràng, dứt khoát (hướng dẫn, quảng cáo, hành động)",
                avatarEmoji = "👨"
            ),
            VoiceOption(
                id = "vi-VN-MaiPhuongNeural",
                name = "Mai Phương",
                region = "Miền Nam",
                gender = "Nữ",
                description = "Giọng nhẹ nhàng, duyên dáng, tự nhiên",
                avatarEmoji = "👧"
            )
        )

        fun findById(id: String): VoiceOption =
            ALL_VOICES.find { it.id == id } ?: ALL_VOICES.first()
    }
}
