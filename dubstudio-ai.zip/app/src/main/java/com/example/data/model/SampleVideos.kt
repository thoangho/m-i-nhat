package com.example.data.model

data class SampleVideoItem(
    val id: String,
    val title: String,
    val category: String,
    val aspectRatio: AspectRatio,
    val durationSeconds: Int,
    val description: String,
    val badge: String,
    val initialSegments: List<SubtitleSegmentSeed>
)

data class SubtitleSegmentSeed(
    val startMs: Long,
    val endMs: Long,
    val chinese: String,
    val vietnamese: String
)

object SampleVideoRepository {
    val SAMPLES = listOf(
        SampleVideoItem(
            id = "sample_douyin_street_food",
            title = "Ẩm thực Trùng Khánh: Lẩu cay tê siêu cay",
            category = "Ẩm thực Douyin",
            aspectRatio = AspectRatio.VERTICAL_9_16,
            durationSeconds = 18,
            description = "Video ẩm thực đường phố Douyin sôi động với phụ đề chân màn hình",
            badge = "HOT DOUYIN",
            initialSegments = listOf(
                SubtitleSegmentSeed(
                    startMs = 500,
                    endMs = 3800,
                    chinese = "今天带大家来尝尝重庆正宗九宫格老火锅！",
                    vietnamese = "Hôm nay mình dẫn mọi người đi thử lẩu 9 ô chuẩn vị Trùng Khánh nhé!"
                ),
                SubtitleSegmentSeed(
                    startMs = 4200,
                    endMs = 7500,
                    chinese = "看看这个牛油红亮，麻辣鲜香扑鼻而来。",
                    vietnamese = "Nhìn nồi nước lèo đỏ au béo ngậy này, mùi cay nồng thơm nức mũi luôn."
                ),
                SubtitleSegmentSeed(
                    startMs = 8000,
                    endMs = 11500,
                    chinese = "毛肚七上八下，脆爽弹牙，真的绝绝子！",
                    vietnamese = "Nhúng sách bò đúng 7 lên 8 xuống, giòn sần sật, đỉnh nóc kịch trần thật sự!"
                ),
                SubtitleSegmentSeed(
                    startMs = 12000,
                    endMs = 15500,
                    chinese = "蘸上满满的蒜泥香油，一点都不觉得燥辣。",
                    vietnamese = "Chấm ngập trong dầu mè tỏi phi, vừa thơm lừng lại không bị gắt họng."
                ),
                SubtitleSegmentSeed(
                    startMs = 16000,
                    endMs = 18000,
                    chinese = "老铁们赶紧点赞收藏，下次一起来打卡！",
                    vietnamese = "Cả nhà nhớ bấm tim và lưu lại ngay, lần sau cùng ghé thử nha!"
                )
            )
        ),
        SampleVideoItem(
            id = "sample_tech_review",
            title = "Trên tay Smartphone gập thế hệ mới nhất",
            category = "Công nghệ Review",
            aspectRatio = AspectRatio.HORIZONTAL_16_9,
            durationSeconds = 20,
            description = "Video đánh giá công nghệ màn hình ngang 16:9 chuẩn YouTube Shorts & FB",
            badge = "16:9 TECH",
            initialSegments = listOf(
                SubtitleSegmentSeed(
                    startMs = 800,
                    endMs = 4200,
                    chinese = "这款全新的折叠屏手机，上手质感完全颠覆我的想象。",
                    vietnamese = "Chiếc điện thoại màn hình gập mới này khi cầm trên tay thực sự vượt xa kỳ vọng của mình."
                ),
                SubtitleSegmentSeed(
                    startMs = 4600,
                    endMs = 8200,
                    chinese = "折痕处理得非常平整，展开几乎感觉不到它的存在。",
                    vietnamese = "Phần nếp gấp được xử lý siêu phẳng, mở ra hầu như không cảm nhận thấy vết hằn nào."
                ),
                SubtitleSegmentSeed(
                    startMs = 8600,
                    endMs = 12500,
                    chinese = "配备最新的高通旗舰芯片，玩大型游戏完全满帧流畅。",
                    vietnamese = "Được trang bị con chip Snapdragon đầu bảng mới nhất, chiến game nặng cực kỳ mượt mà."
                ),
                SubtitleSegmentSeed(
                    startMs = 13000,
                    endMs = 16500,
                    chinese = "影像系统升级巨大，夜景拍摄色彩极其通透细腻。",
                    vietnamese = "Hệ thống camera nâng cấp vượt trội, ảnh chụp đêm trong trẻo và chi tiết ấn tượng."
                ),
                SubtitleSegmentSeed(
                    startMs = 17000,
                    endMs = 19800,
                    chinese = "整体而言，这是目前我认为最具性价比的折叠旗舰。",
                    vietnamese = "Tổng kết lại, đây chính là mẫu flagship gập đáng đồng tiền bát gạo nhất hiện nay."
                )
            )
        ),
        SampleVideoItem(
            id = "sample_office_comedy",
            title = "Tình huống công sở: Ngày đầu làm việc",
            category = "Hài kịch Douyin",
            aspectRatio = AspectRatio.VERTICAL_9_16,
            durationSeconds = 17,
            description = "Clip hài kịch châm biếm công sở hài hước viral trên TikTok",
            badge = "HÀI HƯỚC",
            initialSegments = listOf(
                SubtitleSegmentSeed(
                    startMs = 600,
                    endMs = 3800,
                    chinese = "老板问我：你会使用各种办公软件吗？",
                    vietnamese = "Sếp hỏi tôi: Cậu có thành thạo các phần mềm văn phòng không?"
                ),
                SubtitleSegmentSeed(
                    startMs = 4100,
                    endMs = 7300,
                    chinese = "我自信满满地回答：那是相当熟练！",
                    vietnamese = "Tôi tự tin trả lời ngay: Dạ chuyện nhỏ, siêu thành thạo luôn ạ!"
                ),
                SubtitleSegmentSeed(
                    startMs = 7800,
                    endMs = 11200,
                    chinese = "结果上班第一天，连打印机电源在哪里都找不到。",
                    vietnamese = "Ai ngờ ngày đầu đi làm, đến cái công tắc máy in ở đâu tôi cũng không tìm ra."
                ),
                SubtitleSegmentSeed(
                    startMs = 11800,
                    endMs = 15200,
                    chinese = "同事都在憋笑，这尴尬得我能抠出三室一厅！",
                    vietnamese = "Đồng nghiệp ai cũng nhịn cười, ngại đến mức muốn độn thổ luôn các bác ạ!"
                ),
                SubtitleSegmentSeed(
                    startMs = 15500,
                    endMs = 17000,
                    chinese = "快救救孩子吧，太难了！",
                    vietnamese = "Ai cứu tôi với, cuộc sống người lớn khó quá đi!"
                )
            )
        )
    )
}
