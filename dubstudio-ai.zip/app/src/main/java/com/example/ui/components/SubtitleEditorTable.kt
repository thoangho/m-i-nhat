package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SubtitleSegment
import com.example.ui.theme.StudioAmber
import com.example.ui.theme.StudioBgDark
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioCyan
import com.example.ui.theme.StudioGreen
import com.example.ui.theme.StudioPurpleLight
import com.example.ui.theme.StudioRed
import com.example.ui.theme.StudioSurfaceCard
import com.example.ui.theme.StudioSurfaceCardHover

@Composable
fun SubtitleEditorTable(
    segments: List<SubtitleSegment>,
    currentTimeMs: Long,
    onUpdateText: (Long, String) -> Unit,
    onRetranslate: (SubtitleSegment) -> Unit,
    onPreviewVoice: (SubtitleSegment) -> Unit,
    onDeleteSegment: (SubtitleSegment) -> Unit,
    onAddNewSegment: () -> Unit,
    onSeekTo: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .testTag("subtitle_editor_table_container"),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Table Title & Stats Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.TableChart,
                    contentDescription = "Subtitle Editor Table",
                    tint = StudioCyan,
                    modifier = Modifier.size(20.dp)
                )
                Text(
                    text = "3. Bảng chỉnh sửa phụ đề (st.data_editor)",
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Surface(
                shape = RoundedCornerShape(12.dp),
                color = StudioCyan.copy(alpha = 0.15f)
            ) {
                Text(
                    text = "${segments.size} câu thoại",
                    color = StudioCyan,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        }

        Text(
            text = "Kiểm duyệt và chỉnh sửa trực tiếp lời thoại Tiếng Việt trước khi render:",
            color = Color.White.copy(alpha = 0.7f),
            fontSize = 12.sp
        )

        // Segments List
        segments.forEachIndexed { index, seg ->
            val isActive = currentTimeMs in seg.startTimeMs..seg.endTimeMs
            SubtitleRowItem(
                index = index + 1,
                segment = seg,
                isActive = isActive,
                onUpdateText = { onUpdateText(seg.id, it) },
                onRetranslate = { onRetranslate(seg) },
                onPreviewVoice = { onPreviewVoice(seg) },
                onDelete = { onDeleteSegment(seg) },
                onSeek = { onSeekTo(seg.startTimeMs) }
            )
        }

        // Add Segment Button
        Button(
            onClick = onAddNewSegment,
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 4.dp)
                .testTag("add_segment_button"),
            colors = ButtonDefaults.buttonColors(
                containerColor = StudioSurfaceCardHover,
                contentColor = StudioCyan
            ),
            shape = RoundedCornerShape(12.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder)
        ) {
            Icon(
                imageVector = Icons.Default.Add,
                contentDescription = "Thêm đoạn",
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "Thêm câu thoại mới",
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

@Composable
fun SubtitleRowItem(
    index: Int,
    segment: SubtitleSegment,
    isActive: Boolean,
    onUpdateText: (String) -> Unit,
    onRetranslate: () -> Unit,
    onPreviewVoice: () -> Unit,
    onDelete: () -> Unit,
    onSeek: () -> Unit
) {
    var editedText by remember(segment.vietnameseText) { mutableStateOf(segment.vietnameseText) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("subtitle_row_$index"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isActive) Color(0xFF1E2A44) else StudioSurfaceCard
        ),
        border = androidx.compose.foundation.BorderStroke(
            width = if (isActive) 1.5.dp else 1.dp,
            color = if (isActive) StudioCyan else StudioBorder
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Header Row: Index, Time range, Play preview, Re-translate, Delete
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Index & Time
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = if (isActive) StudioCyan else StudioBorder
                    ) {
                        Text(
                            text = "$index",
                            color = if (isActive) StudioBgDark else Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = Color.Black.copy(alpha = 0.5f),
                        modifier = Modifier.clickable { onSeek() }
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "${segment.startTimeFormatted} → ${segment.endTimeFormatted}",
                                color = StudioCyan,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    if (segment.isEdited) {
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = StudioAmber.copy(alpha = 0.2f)
                        ) {
                            Text(
                                text = "Đã chỉnh sửa",
                                color = StudioAmber,
                                fontSize = 10.sp,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                            )
                        }
                    }
                }

                // Row action buttons
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    // Preview Voice
                    IconButton(
                        onClick = onPreviewVoice,
                        modifier = Modifier.size(32.dp).testTag("preview_voice_$index")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                            contentDescription = "Nghe thử",
                            tint = StudioCyan,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    // Re-translate
                    IconButton(
                        onClick = onRetranslate,
                        modifier = Modifier.size(32.dp).testTag("retranslate_$index")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Dịch lại",
                            tint = StudioPurpleLight,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    // Delete
                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier.size(32.dp).testTag("delete_$index")
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteOutline,
                            contentDescription = "Xóa",
                            tint = StudioRed.copy(alpha = 0.8f),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            // Original Chinese Text Box
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp),
                color = Color.Black.copy(alpha = 0.4f),
                border = androidx.compose.foundation.BorderStroke(0.5.dp, StudioBorder)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "🇨🇳 Gốc: ",
                        color = Color.White.copy(alpha = 0.5f),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = segment.originalChinese,
                        color = Color(0xFFFFEB3B),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            // Editable Vietnamese Text Field
            OutlinedTextField(
                value = editedText,
                onValueChange = {
                    editedText = it
                    onUpdateText(it)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("vietnamese_input_$index"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = StudioCyan,
                    unfocusedBorderColor = StudioBorder,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedContainerColor = Color(0xFF0F172A),
                    unfocusedContainerColor = Color(0xFF0F172A)
                ),
                shape = RoundedCornerShape(8.dp),
                textStyle = TextStyle(fontSize = 13.sp, fontWeight = FontWeight.Normal),
                prefix = {
                    Text(
                        text = "🇻🇳 Dịch: ",
                        color = StudioCyan,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                },
                singleLine = false,
                maxLines = 3
            )
        }
    }
}
