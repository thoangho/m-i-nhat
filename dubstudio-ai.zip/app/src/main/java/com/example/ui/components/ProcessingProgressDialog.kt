package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.StudioAmber
import com.example.ui.theme.StudioBgDark
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioCyan
import com.example.ui.theme.StudioGreen
import com.example.ui.theme.StudioPurpleLight
import com.example.ui.theme.StudioSurfaceCard

@Composable
fun ProcessingProgressDialog(
    currentStage: Int,
    stageTitle: String,
    progress: Float,
    logs: List<String>,
    onDismiss: () -> Unit
) {
    val listState = rememberLazyListState()

    LaunchedEffect(logs.size) {
        if (logs.isNotEmpty()) {
            listState.animateScrollToItem(logs.size - 1)
        }
    }

    Dialog(
        onDismissRequest = { /* Prevent accidental cancel during intensive render */ },
        properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .border(1.dp, StudioCyan.copy(alpha = 0.5f), RoundedCornerShape(20.dp))
                .testTag("processing_progress_dialog"),
            color = StudioBgDark
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Memory,
                            contentDescription = "Processing",
                            tint = StudioCyan,
                            modifier = Modifier.size(24.dp)
                        )
                        Column {
                            Text(
                                text = "Tiến trình Xử lý Video Studio",
                                color = Color.White,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Bảo vệ RAM & Chống OOM kích hoạt",
                                color = StudioGreen,
                                fontSize = 11.sp
                            )
                        }
                    }

                    if (progress >= 1.0f) {
                        IconButton(onClick = onDismiss) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Đóng", tint = Color.White)
                        }
                    }
                }

                // 4-Stages Stepper
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    StageStepRow(
                        step = 1,
                        label = "[1/4] Bóc tách tiếng Trung (Whisper AI)",
                        isCurrent = currentStage == 1,
                        isDone = currentStage > 1
                    )
                    StageStepRow(
                        step = 2,
                        label = "[2/4] Dịch 100% sang Tiếng Việt",
                        isCurrent = currentStage == 2,
                        isDone = currentStage > 2
                    )
                    StageStepRow(
                        step = 3,
                        label = "[3/4] Tạo file lồng tiếng AI (Edge-TTS)",
                        isCurrent = currentStage == 3,
                        isDone = currentStage > 3
                    )
                    StageStepRow(
                        step = 4,
                        label = "[4/4] Che phụ đề cũ & render video hoàn chỉnh",
                        isCurrent = currentStage == 4,
                        isDone = progress >= 1.0f
                    )
                }

                // Overall Progress Bar
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = stageTitle,
                            color = StudioCyan,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            maxLines = 1
                        )
                        Text(
                            text = "${(progress * 100).toInt()}%",
                            color = StudioCyan,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = StudioCyan,
                        trackColor = StudioBorder
                    )
                }

                // Terminal-Style System Logs (Garbage collection & memory monitoring)
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(130.dp),
                    shape = RoundedCornerShape(10.dp),
                    color = Color.Black.copy(alpha = 0.85f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder)
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Terminal,
                                contentDescription = "Terminal",
                                tint = StudioAmber,
                                modifier = Modifier.size(13.dp)
                            )
                            Text(
                                text = "HỆ THỐNG GIÁM SÁT HIỆU NĂNG",
                                color = StudioAmber,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        LazyColumn(
                            state = listState,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            items(logs) { log ->
                                Text(
                                    text = log,
                                    color = if (log.contains("torch.cuda") || log.contains("Hoàn tất")) StudioGreen else Color(0xFF94A3B8),
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    lineHeight = 13.sp
                                )
                            }
                        }
                    }
                }

                // Completion Button
                if (progress >= 1.0f) {
                    Button(
                        onClick = onDismiss,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = StudioCyan, contentColor = StudioBgDark),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Mở bản thành phẩm", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun StageStepRow(
    step: Int,
    label: String,
    isCurrent: Boolean,
    isDone: Boolean
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Surface(
            shape = CircleShape,
            color = when {
                isDone -> StudioGreen
                isCurrent -> StudioCyan
                else -> StudioBorder
            },
            modifier = Modifier.size(20.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                if (isDone) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = "Xong",
                        tint = StudioBgDark,
                        modifier = Modifier.size(12.dp)
                    )
                } else if (isCurrent) {
                    CircularProgressIndicator(
                        strokeWidth = 2.dp,
                        color = StudioBgDark,
                        modifier = Modifier.size(12.dp)
                    )
                } else {
                    Text(text = "$step", color = Color.White.copy(alpha = 0.5f), fontSize = 10.sp)
                }
            }
        }

        Text(
            text = label,
            color = when {
                isDone -> StudioGreen
                isCurrent -> Color.White
                else -> Color.White.copy(alpha = 0.4f)
            },
            fontSize = 12.sp,
            fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal
        )
    }
}
