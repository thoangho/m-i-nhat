package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AspectRatio
import com.example.data.model.SampleVideoRepository
import com.example.ui.components.ExportStudioCard
import com.example.ui.components.MaskControlsCard
import com.example.ui.components.ProcessingProgressDialog
import com.example.ui.components.SampleVideoPickerSheet
import com.example.ui.components.SubtitleEditorTable
import com.example.ui.components.VideoPlayerWithOverlay
import com.example.ui.components.VoiceSelectionCard
import com.example.ui.theme.StudioAmber
import com.example.ui.theme.StudioBgDark
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioCyan
import com.example.ui.theme.StudioGreen
import com.example.ui.theme.StudioPurpleLight
import com.example.ui.theme.StudioSurfaceCard
import com.example.ui.viewmodel.StudioViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudioMainScreen(
    viewModel: StudioViewModel,
    modifier: Modifier = Modifier
) {
    val state by viewModel.uiState.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }
    var showSamplePicker by remember { mutableStateOf(false) }

    // Android Photo Picker (zero broad storage permission required)
    val videoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.showNotice("Đã tải video từ máy: ${uri.lastPathSegment}")
        }
    }

    LaunchedEffect(state.userNotice) {
        state.userNotice?.let { notice ->
            snackbarHostState.showSnackbar(notice)
            viewModel.clearNotice()
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = StudioBgDark,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = StudioCyan.copy(alpha = 0.2f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, StudioCyan.copy(alpha = 0.6f))
                        ) {
                            Text(
                                text = "DUB",
                                color = StudioCyan,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Black,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }

                        Column {
                            Text(
                                text = "DubStudio AI",
                                color = Color.White,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Ultra-Stable Video Translator",
                                color = StudioCyan,
                                fontSize = 10.sp
                            )
                        }
                    }
                },
                actions = {
                    // Video Sample Selector Button
                    Surface(
                        modifier = Modifier.padding(end = 8.dp),
                        shape = RoundedCornerShape(8.dp),
                        color = StudioSurfaceCard,
                        border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder)
                    ) {
                        IconButton(
                            onClick = { showSamplePicker = true },
                            modifier = Modifier.size(36.dp).testTag("open_sample_picker_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.VideoLibrary,
                                contentDescription = "Chọn video mẫu",
                                tint = StudioCyan,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    // Quick Auto-Pipeline Button
                    Button(
                        onClick = { viewModel.runFullPipeline() },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = StudioCyan,
                            contentColor = StudioBgDark
                        ),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                        modifier = Modifier.padding(end = 8.dp).testTag("top_run_pipeline_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Xử lý AI", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = StudioBgDark
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            val project = state.activeProject

            if (project != null) {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // 1. Centerpiece Video Player with live mask bar & crisp subtitle overlay
                    item {
                        VideoPlayerWithOverlay(
                            project = project,
                            segments = state.segments,
                            currentTimeMs = state.currentPlaybackTimeMs,
                            isPlaying = state.isPlaying,
                            isSpeakingDubbing = state.isSpeakingPreview,
                            onPlayPauseToggle = { viewModel.togglePlayPause() },
                            onSeek = { viewModel.seekTo(it) },
                            onMaskYChange = { newY ->
                                viewModel.updateMaskConfig(project.maskConfig.copy(yPercent = newY))
                            }
                        )
                    }

                    // 2. Navigation Tabs (Masking, Subtitle Table, Voice Dubbing, Export)
                    item {
                        val tabs = listOf(
                            Triple("Che phụ đề", Icons.Default.Layers, 0),
                            Triple("Bảng phụ đề (${state.segments.size})", Icons.Default.TableChart, 1),
                            Triple("Lồng tiếng AI", Icons.Default.RecordVoiceOver, 2),
                            Triple("Xuất bản", Icons.Default.Movie, 3)
                        )

                        ScrollableTabRow(
                            selectedTabIndex = state.selectedTab,
                            containerColor = StudioBgDark,
                            contentColor = StudioCyan,
                            edgePadding = 0.dp,
                            indicator = { tabPositions ->
                                if (state.selectedTab < tabPositions.size) {
                                    TabRowDefaults.SecondaryIndicator(
                                        Modifier.tabIndicatorOffset(tabPositions[state.selectedTab]),
                                        color = StudioCyan
                                    )
                                }
                            },
                            divider = {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(1.dp)
                                        .background(StudioBorder)
                                )
                            }
                        ) {
                            tabs.forEach { (title, icon, index) ->
                                val isSelected = state.selectedTab == index
                                Tab(
                                    selected = isSelected,
                                    onClick = { viewModel.selectTab(index) },
                                    modifier = Modifier.testTag("tab_$index"),
                                    text = {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Icon(
                                                imageVector = icon,
                                                contentDescription = null,
                                                modifier = Modifier.size(16.dp),
                                                tint = if (isSelected) StudioCyan else Color.White.copy(alpha = 0.5f)
                                            )
                                            Text(
                                                text = title,
                                                color = if (isSelected) StudioCyan else Color.White.copy(alpha = 0.6f),
                                                fontSize = 12.sp,
                                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                            )
                                        }
                                    }
                                )
                            }
                        }
                    }

                    // 3. Active Tab Content
                    item {
                        when (state.selectedTab) {
                            0 -> {
                                // Tab 0: Masking & Subtitle Visual Controls
                                MaskControlsCard(
                                    project = project,
                                    onMaskConfigChange = { viewModel.updateMaskConfig(it) },
                                    onSubtitleConfigChange = { viewModel.updateSubtitleConfig(it) }
                                )
                            }
                            1 -> {
                                // Tab 1: Interactive Subtitle Editor Table (st.data_editor)
                                SubtitleEditorTable(
                                    segments = state.segments,
                                    currentTimeMs = state.currentPlaybackTimeMs,
                                    onUpdateText = { id, text -> viewModel.updateSegmentText(id, text) },
                                    onRetranslate = { seg -> viewModel.retranslateSegment(seg) },
                                    onPreviewVoice = { seg -> viewModel.previewVoiceForSegment(seg) },
                                    onDeleteSegment = { seg -> viewModel.deleteSegment(seg) },
                                    onAddNewSegment = { viewModel.addNewSegment() },
                                    onSeekTo = { timeMs -> viewModel.seekTo(timeMs) }
                                )
                            }
                            2 -> {
                                // Tab 2: Voice Dubbing (Hoài Mỹ / Nam Minh) & Audio Ducking Mixer
                                VoiceSelectionCard(
                                    dubbingConfig = project.dubbingConfig,
                                    availableVoices = state.availableVoices,
                                    onSelectVoice = { viewModel.selectVoice(it) },
                                    onDubbingConfigChange = { viewModel.updateDubbingConfig(it) },
                                    onTestVoice = {
                                        viewModel.previewVoiceForSegment(
                                            state.segments.firstOrNull() ?: return@VoiceSelectionCard
                                        )
                                    }
                                )
                            }
                            3 -> {
                                // Tab 3: Full Pipeline & Export (MP4, SRT, TXT)
                                ExportStudioCard(
                                    project = project,
                                    segments = state.segments,
                                    lastExportedVideo = state.lastExportedVideo,
                                    lastExportedSrt = state.lastExportedSrt,
                                    lastExportedTxt = state.lastExportedTxt,
                                    isRenderingFFmpeg = state.isRenderingFFmpeg,
                                    ffmpegRenderProgress = state.ffmpegRenderProgress,
                                    ffmpegStatusMessage = state.ffmpegStatusMessage,
                                    lastDownloadedFileName = state.lastDownloadedFileName,
                                    ffmpegOptions = state.ffmpegOptions,
                                    onUpdateFFmpegOptions = { viewModel.updateFFmpegOptions(it) },
                                    onTriggerFFmpegRender = { viewModel.startFFmpegRendering(it) },
                                    onDownloadFile = { file, mime -> viewModel.downloadFileToDevice(file, mime) },
                                    onOpenFile = { file, mime -> viewModel.openExportedFile(file, mime) },
                                    onRunFullPipeline = { viewModel.runFullPipeline() },
                                    onExportSrt = { viewModel.exportSrtOnly() },
                                    onExportTranscript = { viewModel.exportTranscriptOnly() }
                                )
                            }
                        }
                    }

                    // Persistent Quick Export Action Card when not on Export tab
                    if (state.selectedTab != 3) {
                        item {
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 4.dp),
                                shape = RoundedCornerShape(14.dp),
                                color = StudioSurfaceCard,
                                border = androidx.compose.foundation.BorderStroke(1.dp, StudioCyan.copy(alpha = 0.5f))
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "Sẵn sàng xuất video?",
                                            color = Color.White,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "FFmpeg đa luồng • Che chữ • Lồng tiếng AI",
                                            color = StudioCyan,
                                            fontSize = 11.sp
                                        )
                                    }

                                    Button(
                                        onClick = {
                                            viewModel.selectTab(3)
                                            viewModel.startFFmpegRendering()
                                        },
                                        shape = RoundedCornerShape(10.dp),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = StudioCyan,
                                            contentColor = StudioBgDark
                                        ),
                                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                                        modifier = Modifier.testTag("quick_ffmpeg_export_button")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.AutoAwesome,
                                            contentDescription = null,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Xuất Video", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }

                    item {
                        Spacer(modifier = Modifier.height(24.dp))
                    }
                }
            } else {
                // Empty state
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = "Đang khởi tạo DubStudio...", color = Color.White)
                }
            }
        }
    }

    // Processing Progress Modal (Real-time 4 stages + logs)
    if (state.isProcessing) {
        ProcessingProgressDialog(
            currentStage = state.processingStage,
            stageTitle = state.processingStageTitle,
            progress = state.processingProgress,
            logs = state.processingLogs,
            onDismiss = { viewModel.dismissProcessingDialog() }
        )
    }

    // Sample video chooser modal
    if (showSamplePicker) {
        SampleVideoPickerSheet(
            activeSampleId = state.activeProject?.id,
            onSelectSample = { viewModel.loadSample(it) },
            onPickCustomVideo = {
                videoPickerLauncher.launch(
                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                )
            },
            onDismiss = { showSamplePicker = false }
        )
    }
}
