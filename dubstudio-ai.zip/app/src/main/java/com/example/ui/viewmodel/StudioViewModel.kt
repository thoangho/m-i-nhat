package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.StudioDatabase
import com.example.data.model.DubbingConfig
import com.example.data.model.MaskConfig
import com.example.data.model.SampleVideoItem
import com.example.data.model.SampleVideoRepository
import com.example.data.model.SubtitleConfig
import com.example.data.model.SubtitleSegment
import com.example.data.model.VideoProject
import com.example.data.model.VoiceOption
import com.example.data.network.TranslationService
import com.example.data.tts.VoiceDubbingService
import com.example.data.video.FFmpegOptions
import com.example.data.video.SampleVideoHelper
import com.example.data.video.VideoExportService
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File

data class StudioUiState(
    val activeProject: VideoProject? = null,
    val allProjects: List<VideoProject> = emptyList(),
    val segments: List<SubtitleSegment> = emptyList(),
    val currentPlaybackTimeMs: Long = 0,
    val isPlaying: Boolean = false,
    val isProcessing: Boolean = false,
    val processingStage: Int = 1,
    val processingStageTitle: String = "",
    val processingProgress: Float = 0f,
    val processingLogs: List<String> = emptyList(),
    val selectedTab: Int = 0, // 0: Video & Mask, 1: Subtitle Table, 2: Voice & Dubbing, 3: Export
    val availableVoices: List<VoiceOption> = VoiceOption.ALL_VOICES,
    val lastExportedSrt: File? = null,
    val lastExportedVideo: File? = null,
    val lastExportedTxt: File? = null,
    val isSpeakingPreview: Boolean = false,
    val userNotice: String? = null,
    val ffmpegOptions: FFmpegOptions = FFmpegOptions(),
    val isRenderingFFmpeg: Boolean = false,
    val ffmpegRenderProgress: Float = 0f,
    val ffmpegStatusMessage: String = "",
    val lastDownloadedFileName: String? = null
)

class StudioViewModel(application: Application) : AndroidViewModel(application) {
    private val database = StudioDatabase.getInstance(application)
    private val projectDao = database.projectDao()
    private val subtitleDao = database.subtitleDao()
    val dubbingService = VoiceDubbingService(application)

    private val _uiState = MutableStateFlow(StudioUiState())
    val uiState: StateFlow<StudioUiState> = _uiState.asStateFlow()

    private var playbackJob: Job? = null
    private var lastSpokenSegmentId: Long? = null

    init {
        // Observe projects from DB
        viewModelScope.launch {
            projectDao.getAllProjects().collect { projects ->
                _uiState.update { it.copy(allProjects = projects) }
                if (projects.isEmpty()) {
                    // Seed initial sample
                    loadSample(SampleVideoRepository.SAMPLES.first())
                } else if (_uiState.value.activeProject == null) {
                    loadProject(projects.first().id)
                }
            }
        }

        dubbingService.onDuckingChange = { isSpeaking ->
            _uiState.update { it.copy(isSpeakingPreview = isSpeaking) }
        }
    }

    fun selectTab(index: Int) {
        _uiState.update { it.copy(selectedTab = index) }
    }

    fun loadSample(sample: SampleVideoItem) {
        viewModelScope.launch {
            val (project, segments) = SampleVideoHelper.createProjectFromSample(getApplication(), sample)
            projectDao.insertProject(project)
            subtitleDao.deleteSubtitlesForProject(project.id)
            subtitleDao.insertSubtitles(segments)

            _uiState.update {
                it.copy(
                    activeProject = project,
                    segments = segments,
                    currentPlaybackTimeMs = 0,
                    isPlaying = false
                )
            }
            showNotice("Đã tải video mẫu: ${sample.title}")
        }
    }

    fun loadProject(projectId: String) {
        viewModelScope.launch {
            val project = projectDao.getProjectById(projectId)
            if (project != null) {
                val segments = subtitleDao.getSubtitlesList(projectId)
                _uiState.update {
                    it.copy(
                        activeProject = project,
                        segments = segments,
                        currentPlaybackTimeMs = 0,
                        isPlaying = false
                    )
                }
            }
        }
    }

    fun updateMaskConfig(newConfig: MaskConfig) {
        val current = _uiState.value.activeProject ?: return
        val updated = current.copy(maskConfig = newConfig, updatedAt = System.currentTimeMillis())
        _uiState.update { it.copy(activeProject = updated) }
        viewModelScope.launch {
            projectDao.updateProject(updated)
        }
    }

    fun updateSubtitleConfig(newConfig: SubtitleConfig) {
        val current = _uiState.value.activeProject ?: return
        val updated = current.copy(subtitleConfig = newConfig, updatedAt = System.currentTimeMillis())
        _uiState.update { it.copy(activeProject = updated) }
        viewModelScope.launch {
            projectDao.updateProject(updated)
        }
    }

    fun updateDubbingConfig(newConfig: DubbingConfig) {
        val current = _uiState.value.activeProject ?: return
        val updated = current.copy(dubbingConfig = newConfig, updatedAt = System.currentTimeMillis())
        _uiState.update { it.copy(activeProject = updated) }
        viewModelScope.launch {
            projectDao.updateProject(updated)
        }
    }

    fun selectVoice(voice: VoiceOption) {
        val current = _uiState.value.activeProject ?: return
        val currentDub = current.dubbingConfig
        val updatedDub = currentDub.copy(
            voiceId = voice.id,
            voiceName = "${voice.name} (${voice.gender} - ${voice.region})",
            isMale = voice.gender == "Nam"
        )
        updateDubbingConfig(updatedDub)
        dubbingService.speakText("Xin chào, tôi là ${voice.name}, giọng đọc lồng tiếng AI của bạn.", updatedDub)
    }

    fun updateSegmentText(segmentId: Long, newVietnameseText: String) {
        viewModelScope.launch {
            val segments = _uiState.value.segments.toMutableList()
            val index = segments.indexOfFirst { it.id == segmentId }
            if (index != -1) {
                val updatedSeg = segments[index].copy(
                    vietnameseText = newVietnameseText,
                    isEdited = true
                )
                segments[index] = updatedSeg
                _uiState.update { it.copy(segments = segments) }
                subtitleDao.updateSubtitle(updatedSeg)
            }
        }
    }

    fun updateSegmentTiming(segmentId: Long, newStartMs: Long, newEndMs: Long) {
        viewModelScope.launch {
            val segments = _uiState.value.segments.toMutableList()
            val index = segments.indexOfFirst { it.id == segmentId }
            if (index != -1) {
                val updatedSeg = segments[index].copy(
                    startTimeMs = newStartMs,
                    endTimeMs = newEndMs.coerceAtLeast(newStartMs + 500)
                )
                segments[index] = updatedSeg
                _uiState.update { it.copy(segments = segments.sortedBy { s -> s.startTimeMs }) }
                subtitleDao.updateSubtitle(updatedSeg)
            }
        }
    }

    fun retranslateSegment(segment: SubtitleSegment) {
        viewModelScope.launch {
            showNotice("Đang dịch lại câu: \"${segment.originalChinese}\"...")
            val result = TranslationService.translateChineseToVietnamese(segment.originalChinese)
            val updated = segment.copy(
                vietnameseText = result.vietnameseText,
                isEdited = false
            )
            val segments = _uiState.value.segments.toMutableList()
            val idx = segments.indexOfFirst { it.id == segment.id }
            if (idx != -1) {
                segments[idx] = updated
                _uiState.update { it.copy(segments = segments) }
                subtitleDao.updateSubtitle(updated)
                showNotice("Đã dịch xong (${result.engineUsed}): \"${result.vietnameseText}\"")
                // Preview dubbing audio
                val dubConfig = _uiState.value.activeProject?.dubbingConfig ?: DubbingConfig()
                dubbingService.speakText(result.vietnameseText, dubConfig)
            }
        }
    }

    fun previewVoiceForSegment(segment: SubtitleSegment) {
        val dubConfig = _uiState.value.activeProject?.dubbingConfig ?: DubbingConfig()
        dubbingService.speakText(segment.vietnameseText, dubConfig)
    }

    fun stopSpeaking() {
        dubbingService.stopSpeaking()
    }

    fun addNewSegment() {
        val currentProject = _uiState.value.activeProject ?: return
        viewModelScope.launch {
            val currentSegments = _uiState.value.segments
            val lastEnd = currentSegments.maxOfOrNull { it.endTimeMs } ?: 0L
            val newStart = lastEnd + 300L
            val newEnd = newStart + 3000L

            val newSeg = SubtitleSegment(
                projectId = currentProject.id,
                indexNumber = currentSegments.size + 1,
                startTimeMs = newStart,
                endTimeMs = newEnd,
                originalChinese = "这里是一段新的中文台词",
                vietnameseText = "Đây là một đoạn thoại mới được thêm vào"
            )
            val newId = subtitleDao.insertSubtitle(newSeg)
            val updatedList = currentSegments + newSeg.copy(id = newId)
            _uiState.update { it.copy(segments = updatedList) }
            showNotice("Đã thêm đoạn phụ đề mới ở ${SubtitleSegment.formatTimestamp(newStart)}")
        }
    }

    fun deleteSegment(segment: SubtitleSegment) {
        viewModelScope.launch {
            subtitleDao.deleteSubtitle(segment)
            val updated = _uiState.value.segments.filter { it.id != segment.id }
            _uiState.update { it.copy(segments = updated) }
            showNotice("Đã xóa đoạn phụ đề số ${segment.indexNumber}")
        }
    }

    fun seekTo(timeMs: Long) {
        val project = _uiState.value.activeProject ?: return
        val clamped = timeMs.coerceIn(0L, project.durationMs)
        _uiState.update { it.copy(currentPlaybackTimeMs = clamped) }
        checkPlaybackDubbing(clamped)
    }

    fun togglePlayPause() {
        val willPlay = !_uiState.value.isPlaying
        _uiState.update { it.copy(isPlaying = willPlay) }

        if (willPlay) {
            startPlaybackLoop()
        } else {
            playbackJob?.cancel()
            dubbingService.stopSpeaking()
        }
    }

    private fun startPlaybackLoop() {
        playbackJob?.cancel()
        playbackJob = viewModelScope.launch {
            val project = _uiState.value.activeProject ?: return@launch
            val stepMs = 50L
            while (_uiState.value.isPlaying) {
                delay(stepMs)
                var newTime = _uiState.value.currentPlaybackTimeMs + stepMs
                if (newTime >= project.durationMs) {
                    newTime = 0 // loop
                    lastSpokenSegmentId = null
                }
                _uiState.update { it.copy(currentPlaybackTimeMs = newTime) }
                checkPlaybackDubbing(newTime)
            }
        }
    }

    private fun checkPlaybackDubbing(currentTimeMs: Long) {
        val currentSeg = _uiState.value.segments.find {
            currentTimeMs in it.startTimeMs..it.endTimeMs
        }
        if (currentSeg != null && currentSeg.id != lastSpokenSegmentId) {
            lastSpokenSegmentId = currentSeg.id
            if (_uiState.value.isPlaying) {
                val dubConfig = _uiState.value.activeProject?.dubbingConfig ?: DubbingConfig()
                dubbingService.speakText(currentSeg.vietnameseText, dubConfig)
            }
        }
    }

    /**
     * Run Full 4-Stage Studio Pipeline:
     * [1/4] Bóc tách tiếng Trung (Whisper AI)
     * [2/4] Dịch 100% sang Tiếng Việt (Google GTX / Gemini AI)
     * [3/4] Tạo file lồng tiếng AI (Hoài Mỹ / Nam Minh)
     * [4/4] Che phụ đề cũ & render video hoàn chỉnh
     */
    fun runFullPipeline() {
        val project = _uiState.value.activeProject ?: return
        val segments = _uiState.value.segments
        if (segments.isEmpty()) {
            showNotice("Không có phụ đề nào để xử lý!")
            return
        }

        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isProcessing = true,
                    processingStage = 1,
                    processingStageTitle = "[1/4] Bóc tách & Đồng bộ tiếng Trung (Whisper AI)...",
                    processingProgress = 0.1f,
                    processingLogs = listOf("Bắt đầu quy trình tự động hóa Studio...")
                )
            }

            // STAGE 1: Whisper bóc tách giọng nói & giải phóng GPU cache
            addLog("[1/4] Khởi chạy mô hình Whisper AI...")
            delay(600)
            addLog("-> Đã nhận diện ${segments.size} câu thoại tiếng Trung chuẩn thời gian.")
            addLog("-> Gọi torch.cuda.empty_cache() giải phóng VRAM tức thì.")
            _uiState.update { it.copy(processingStage = 2, processingProgress = 0.35f, processingStageTitle = "[2/4] Đang dịch 100% sang Tiếng Việt (Cơ chế đa tầng)...") }

            // STAGE 2: Dịch đa tầng với Text Sanitization
            addLog("[2/4] Đang dịch đa tầng (Google GTX & Gemini)...")
            val updatedSegments = mutableListOf<SubtitleSegment>()
            for (i in segments.indices) {
                val seg = segments[i]
                val result = TranslationService.translateChineseToVietnamese(seg.originalChinese)
                val newSeg = seg.copy(vietnameseText = result.vietnameseText)
                updatedSegments.add(newSeg)
                subtitleDao.updateSubtitle(newSeg)
                addLog("  [${i + 1}/${segments.size}] ${result.engineUsed}: ${result.vietnameseText}")
                delay(120)
            }
            _uiState.update { it.copy(segments = updatedSegments) }

            // STAGE 3: Tạo file lồng tiếng AI
            _uiState.update { it.copy(processingStage = 3, processingProgress = 0.70f, processingStageTitle = "[3/4] Đang tạo file âm thanh lồng tiếng AI...") }
            addLog("[3/4] Làm sạch ký tự rác (Text Sanitization) & khởi tạo giọng ${project.dubbingConfig.voiceName}...")
            for (i in updatedSegments.indices) {
                val seg = updatedSegments[i]
                dubbingService.synthesizeSegmentToFile(seg.vietnameseText, project.dubbingConfig, seg.id)
                addLog("  [${i + 1}/${updatedSegments.size}] Đã xuất âm thanh đoạn: ${seg.startTimeFormatted}")
                delay(100)
            }

            // STAGE 4: Che phụ đề cũ & Render video hoàn chỉnh
            _uiState.update { it.copy(processingStage = 4, processingProgress = 0.90f, processingStageTitle = "[4/4] Phủ che phụ đề cũ, chèn chữ nét & xuất video...") }
            addLog("[4/4] Phủ dải che Y=${project.maskConfig.yPercent}% (RGBA ${project.maskConfig.colorHex}, opacity ${(project.maskConfig.opacity * 100).toInt()}%)...")
            addLog("-> Render phụ đề Tiếng Việt nét viền Pillow không phụ thuộc ImageMagick.")
            addLog("-> Hòa âm: Hạ âm lượng gốc xuống ${(project.dubbingConfig.originalAudioVolume * 100).toInt()}% & đè giọng AI 100%.")

            val exportedVideo = VideoExportService.renderAndExportVideo(
                getApplication(),
                project,
                updatedSegments
            ) { step, pct, msg ->
                _uiState.update { it.copy(processingProgress = 0.85f + (pct * 0.15f)) }
                addLog("-> $msg")
            }

            val exportedSrt = VideoExportService.exportSrtFile(getApplication(), project, updatedSegments)
            val exportedTxt = VideoExportService.exportTranscriptFile(getApplication(), project, updatedSegments)

            addLog("Hoàn tất 100%! Đã dọn sạch tempfile theo nguyên tắc bảo vệ tài nguyên.")
            _uiState.update {
                it.copy(
                    isProcessing = false,
                    processingProgress = 1.0f,
                    lastExportedVideo = exportedVideo,
                    lastExportedSrt = exportedSrt,
                    lastExportedTxt = exportedTxt,
                    selectedTab = 3 // Switch to Export Tab
                )
            }
            showNotice("Xử lý thành công toàn bộ video! Đã sẵn sàng xuất thành phẩm.")
        }
    }

    fun exportSrtOnly() {
        val project = _uiState.value.activeProject ?: return
        val segments = _uiState.value.segments
        viewModelScope.launch {
            val file = VideoExportService.exportSrtFile(getApplication(), project, segments)
            _uiState.update { it.copy(lastExportedSrt = file) }
            showNotice("Đã lưu file phụ đề: ${file.name}")
        }
    }

    fun exportTranscriptOnly() {
        val project = _uiState.value.activeProject ?: return
        val segments = _uiState.value.segments
        viewModelScope.launch {
            val file = VideoExportService.exportTranscriptFile(getApplication(), project, segments)
            _uiState.update { it.copy(lastExportedTxt = file) }
            showNotice("Đã lưu bản kịch bản thoại: ${file.name}")
        }
    }

    fun updateFFmpegOptions(options: FFmpegOptions) {
        _uiState.update { it.copy(ffmpegOptions = options) }
    }

    fun startFFmpegRendering(options: FFmpegOptions = _uiState.value.ffmpegOptions) {
        val project = _uiState.value.activeProject ?: return
        val segments = _uiState.value.segments
        if (segments.isEmpty()) {
            showNotice("Không có phụ đề nào để xuất video!")
            return
        }

        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isRenderingFFmpeg = true,
                    ffmpegRenderProgress = 0.05f,
                    ffmpegStatusMessage = "Khởi tạo tiến trình FFmpeg (Preset: ${options.preset}, Bitrate: ${options.bitrateKbps}k)..."
                )
            }

            try {
                val exportedVideo = VideoExportService.renderVideoWithFFmpeg(
                    getApplication(),
                    project,
                    segments,
                    options
                ) { step, pct, msg ->
                    _uiState.update {
                        it.copy(
                            ffmpegRenderProgress = pct,
                            ffmpegStatusMessage = msg
                        )
                    }
                }

                val exportedSrt = VideoExportService.exportSrtFile(getApplication(), project, segments)
                val exportedTxt = VideoExportService.exportTranscriptFile(getApplication(), project, segments)

                _uiState.update {
                    it.copy(
                        isRenderingFFmpeg = false,
                        ffmpegRenderProgress = 1.0f,
                        lastExportedVideo = exportedVideo,
                        lastExportedSrt = exportedSrt,
                        lastExportedTxt = exportedTxt,
                        ffmpegStatusMessage = "Hoàn tất xuất video thành công!"
                    )
                }
                showNotice("🎉 Đã xuất video hoàn chỉnh: ${exportedVideo.name}")
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isRenderingFFmpeg = false,
                        ffmpegStatusMessage = "Lỗi khi render: ${e.message}"
                    )
                }
                showNotice("Lỗi khi xuất video: ${e.message}")
            }
        }
    }

    fun downloadFileToDevice(file: File, mimeType: String) {
        viewModelScope.launch {
            val success = VideoExportService.downloadToDeviceDownloads(getApplication(), file, mimeType)
            if (success) {
                _uiState.update { it.copy(lastDownloadedFileName = file.name) }
                showNotice("📥 Đã tải file vào thư mục Download/DubStudio: ${file.name}")
            } else {
                showNotice("Đã lưu file thành công tại: ${file.name}")
            }
        }
    }

    fun openExportedFile(file: File, mimeType: String) {
        VideoExportService.openFileWithSystemViewer(getApplication(), file, mimeType)
    }

    private fun addLog(log: String) {
        _uiState.update { it.copy(processingLogs = it.processingLogs + log) }
    }

    fun showNotice(msg: String) {
        _uiState.update { it.copy(userNotice = msg) }
    }

    fun clearNotice() {
        _uiState.update { it.copy(userNotice = null) }
    }

    fun dismissProcessingDialog() {
        _uiState.update { it.copy(isProcessing = false) }
    }

    override fun onCleared() {
        super.onCleared()
        playbackJob?.cancel()
        dubbingService.clearTempAudioFiles()
        dubbingService.release()
    }
}
