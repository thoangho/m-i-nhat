package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Equalizer
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.VolumeDown
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DubbingConfig
import com.example.data.model.VoiceOption
import com.example.ui.theme.StudioAmber
import com.example.ui.theme.StudioBgDark
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioCyan
import com.example.ui.theme.StudioGreen
import com.example.ui.theme.StudioPurpleLight
import com.example.ui.theme.StudioSurfaceCard
import com.example.ui.theme.StudioSurfaceCardHover

@Composable
fun VoiceSelectionCard(
    dubbingConfig: DubbingConfig,
    availableVoices: List<VoiceOption>,
    onSelectVoice: (VoiceOption) -> Unit,
    onDubbingConfigChange: (DubbingConfig) -> Unit,
    onTestVoice: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("voice_selection_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = StudioSurfaceCard),
        border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.RecordVoiceOver,
                        contentDescription = "Voice Dubbing",
                        tint = StudioCyan,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = "4. Đổi giọng đọc lồng tiếng AI",
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Button(
                    onClick = onTestVoice,
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = StudioCyan.copy(alpha = 0.2f),
                        contentColor = StudioCyan
                    ),
                    modifier = Modifier.testTag("test_voice_sample_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                        contentDescription = "Nghe thử",
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Nghe thử", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }

            // Voice selection buttons
            Text(
                text = "Chọn giọng đọc AI chuẩn Tiếng Việt (Edge-TTS):",
                color = Color.White.copy(alpha = 0.7f),
                fontSize = 12.sp
            )

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                availableVoices.forEach { voice ->
                    val isSelected = dubbingConfig.voiceId == voice.id
                    VoiceOptionItem(
                        voice = voice,
                        isSelected = isSelected,
                        onClick = { onSelectVoice(voice) }
                    )
                }
            }

            // 5. Audio Mixer & Ducking Controls
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                color = Color.Black.copy(alpha = 0.35f),
                border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder)
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Equalizer,
                            contentDescription = "Audio Mixer",
                            tint = StudioAmber,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = "5. Hòa âm tự động (Audio Ducking Mixer)",
                            color = StudioAmber,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Slider: Nhạc nền / Thoại gốc (10% default)
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Âm lượng nhạc nền / tiếng gốc (BGM)",
                                color = Color.White,
                                fontSize = 12.sp
                            )
                            Text(
                                text = "${(dubbingConfig.originalAudioVolume * 100).toInt()}% (Hạ nền tự động)",
                                color = StudioCyan,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Slider(
                            value = dubbingConfig.originalAudioVolume,
                            onValueChange = { onDubbingConfigChange(dubbingConfig.copy(originalAudioVolume = it)) },
                            valueRange = 0.0f..0.50f,
                            colors = SliderDefaults.colors(
                                thumbColor = StudioCyan,
                                activeTrackColor = StudioCyan
                            ),
                            modifier = Modifier.testTag("bgm_volume_slider")
                        )
                    }

                    // Slider: Âm lượng lồng tiếng AI (100% default)
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Âm lượng lồng tiếng AI Tiếng Việt",
                                color = Color.White,
                                fontSize = 12.sp
                            )
                            Text(
                                text = "${(dubbingConfig.dubVoiceVolume * 100).toInt()}%",
                                color = StudioGreen,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Slider(
                            value = dubbingConfig.dubVoiceVolume,
                            onValueChange = { onDubbingConfigChange(dubbingConfig.copy(dubVoiceVolume = it)) },
                            valueRange = 0.5f..1.0f,
                            colors = SliderDefaults.colors(
                                thumbColor = StudioGreen,
                                activeTrackColor = StudioGreen
                            ),
                            modifier = Modifier.testTag("tts_volume_slider")
                        )
                    }

                    // Speech Rate Slider
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Tốc độ đọc: ${String.format("%.2f", dubbingConfig.speechRate)}x",
                                color = Color.White.copy(alpha = 0.8f),
                                fontSize = 12.sp
                            )
                            Slider(
                                value = dubbingConfig.speechRate,
                                onValueChange = { onDubbingConfigChange(dubbingConfig.copy(speechRate = it)) },
                                valueRange = 0.8f..1.4f,
                                colors = SliderDefaults.colors(thumbColor = StudioPurpleLight, activeTrackColor = StudioPurpleLight)
                            )
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Cao độ giọng: ${String.format("%.2f", dubbingConfig.pitch)}x",
                                color = Color.White.copy(alpha = 0.8f),
                                fontSize = 12.sp
                            )
                            Slider(
                                value = dubbingConfig.pitch,
                                onValueChange = { onDubbingConfigChange(dubbingConfig.copy(pitch = it)) },
                                valueRange = 0.8f..1.3f,
                                colors = SliderDefaults.colors(thumbColor = StudioAmber, activeTrackColor = StudioAmber)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun VoiceOptionItem(
    voice: VoiceOption,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("voice_option_${voice.id}"),
        shape = RoundedCornerShape(12.dp),
        color = if (isSelected) Color(0xFF1E293B) else StudioSurfaceCardHover,
        border = androidx.compose.foundation.BorderStroke(
            width = if (isSelected) 1.5.dp else 1.dp,
            color = if (isSelected) StudioCyan else StudioBorder
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Avatar
            Surface(
                shape = CircleShape,
                color = if (isSelected) StudioCyan.copy(alpha = 0.2f) else Color.Black.copy(alpha = 0.4f),
                modifier = Modifier.size(44.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(text = voice.avatarEmoji, fontSize = 22.sp)
                }
            }

            // Info
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "${voice.gender} - ${voice.name} (${voice.region})",
                        color = if (isSelected) StudioCyan else Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    if (isSelected) {
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = StudioCyan
                        ) {
                            Text(
                                text = "ĐANG CHỌN",
                                color = StudioBgDark,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = voice.description,
                    color = Color.White.copy(alpha = 0.65f),
                    fontSize = 11.sp,
                    lineHeight = 15.sp
                )
            }
        }
    }
}
