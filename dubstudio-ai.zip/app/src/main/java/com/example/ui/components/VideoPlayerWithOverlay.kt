package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AspectRatio
import com.example.data.model.MaskConfig
import com.example.data.model.SubtitleConfig
import com.example.data.model.SubtitleSegment
import com.example.data.model.VideoProject
import com.example.ui.theme.StudioAmber
import com.example.ui.theme.StudioBgDark
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioCyan
import com.example.ui.theme.StudioPurple
import com.example.ui.theme.StudioSurfaceCard
import kotlin.math.roundToInt

@Composable
fun VideoPlayerWithOverlay(
    project: VideoProject,
    segments: List<SubtitleSegment>,
    currentTimeMs: Long,
    isPlaying: Boolean,
    isSpeakingDubbing: Boolean,
    onPlayPauseToggle: () -> Unit,
    onSeek: (Long) -> Unit,
    onMaskYChange: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    // Current active segment at this timestamp
    val activeSegment = remember(segments, currentTimeMs) {
        segments.find { currentTimeMs in it.startTimeMs..it.endTimeMs }
    }

    val isVertical = project.aspectRatio == AspectRatio.VERTICAL_9_16
    val ratioValue = if (isVertical) 9f / 16f else 16f / 9f

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(StudioBgDark)
            .border(1.dp, StudioBorder, RoundedCornerShape(16.dp))
            .padding(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Player Container Box
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxWidth()
                .height(if (isVertical) 340.dp else 220.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xFF0F172A)),
            contentAlignment = Alignment.Center
        ) {
            val containerWidth = maxWidth
            val containerHeight = maxHeight

            // Video Screen Frame
            Box(
                modifier = Modifier
                    .aspectRatio(ratioValue)
                    .fillMaxSize()
                    .clip(RoundedCornerShape(8.dp))
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                Color(0xFF1E293B),
                                Color(0xFF0F172A),
                                Color(0xFF020617)
                            )
                        )
                    )
            ) {
                // Animated dynamic scene background
                AnimatedSceneCanvas(
                    category = project.title,
                    isPlaying = isPlaying,
                    currentTimeMs = currentTimeMs,
                    modifier = Modifier.fillMaxSize()
                )

                // Top Metadata Pills
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = Color.Black.copy(alpha = 0.7f),
                        border = androidx.compose.foundation.BorderStroke(0.5.dp, StudioCyan.copy(alpha = 0.5f))
                    ) {
                        Text(
                            text = if (isVertical) "📱 9:16 DỌC" else "🖥️ 16:9 NGANG",
                            color = StudioCyan,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }

                    if (isSpeakingDubbing) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = StudioPurple.copy(alpha = 0.85f)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.GraphicEq,
                                    contentDescription = "Audio Ducking",
                                    tint = Color.White,
                                    modifier = Modifier.size(13.dp)
                                )
                                Text(
                                    text = "Lồng tiếng AI (BGM -90%)",
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }

                // SIMULATED ORIGINAL CHINESE SUBTITLE (Underneath the mask)
                // This represents the Douyin/TikTok video's hardcoded Chinese subtitles
                if (activeSegment != null) {
                    val originalY = (project.maskConfig.yPercent / 100f) * containerHeight.value
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .offset { IntOffset(0, (originalY * density).roundToInt()) },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = activeSegment.originalChinese,
                            color = Color(0xFFFFEB3B), // Classic yellow Douyin subtitle
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 16.dp)
                        )
                    }
                }

                // 1. SUBTITLE MASK BAR (Che phụ đề Tiếng Trung cũ)
                val maskConfig = project.maskConfig
                val maskTopOffset = (maskConfig.yPercent / 100f) * containerHeight.value
                val maskWidth = containerWidth * (maskConfig.widthPercent / 100f)
                val maskHeight = containerHeight * (maskConfig.heightPercent / 100f)

                Box(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .offset { IntOffset(0, (maskTopOffset * density).roundToInt()) }
                        .width(maskWidth)
                        .height(maskHeight)
                        .clip(RoundedCornerShape(maskConfig.cornerRadiusDp.dp))
                        .background(
                            Color.Black.copy(alpha = maskConfig.opacity)
                        )
                        .pointerInput(Unit) {
                            detectDragGestures { change, dragAmount ->
                                change.consume()
                                val deltaPercent = (dragAmount.y / (containerHeight.value * density)) * 100f
                                val newY = (maskConfig.yPercent + deltaPercent).coerceIn(30f, 95f)
                                onMaskYChange(newY)
                            }
                        }
                        .border(
                            width = 1.dp,
                            color = StudioCyan.copy(alpha = 0.4f),
                            shape = RoundedCornerShape(maskConfig.cornerRadiusDp.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    // Visual handle hint on mask bar
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .padding(top = 2.dp)
                            .size(width = 24.dp, height = 3.dp)
                            .clip(CircleShape)
                            .background(StudioCyan.copy(alpha = 0.6f))
                    )
                }

                // 2. CRISP VIETNAMESE SUBTITLE OVERLAY (Chèn phụ đề Tiếng Việt nét căng)
                if (activeSegment != null && activeSegment.vietnameseText.isNotBlank()) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .offset { IntOffset(0, (maskTopOffset * density).roundToInt()) }
                            .width(maskWidth)
                            .height(maskHeight)
                            .padding(horizontal = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        // Sharp text with Stroke & Shadow (Pillow-style)
                        Text(
                            text = activeSegment.vietnameseText,
                            style = TextStyle(
                                color = Color.White,
                                fontSize = project.subtitleConfig.fontSizeSp.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center,
                                shadow = Shadow(
                                    color = Color.Black,
                                    offset = Offset(2f, 2f),
                                    blurRadius = 4f
                                )
                            ),
                            maxLines = project.subtitleConfig.maxLines,
                            modifier = Modifier.testTag("rendered_vietnamese_subtitle")
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Playback Scrubber & Controls
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Play/Pause button
            IconButton(
                onClick = onPlayPauseToggle,
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(StudioCyan)
                    .testTag("play_pause_button")
            ) {
                Icon(
                    imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                    contentDescription = if (isPlaying) "Tạm dừng" else "Phát",
                    tint = StudioBgDark
                )
            }

            // Current Time
            Text(
                text = SubtitleSegment.formatTimestamp(currentTimeMs),
                color = StudioCyan,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )

            // Slider
            val duration = project.durationMs.coerceAtLeast(1000L).toFloat()
            Slider(
                value = currentTimeMs.toFloat().coerceIn(0f, duration),
                onValueChange = { onSeek(it.toLong()) },
                valueRange = 0f..duration,
                colors = SliderDefaults.colors(
                    thumbColor = StudioCyan,
                    activeTrackColor = StudioCyan,
                    inactiveTrackColor = StudioBorder
                ),
                modifier = Modifier
                    .weight(1f)
                    .testTag("video_scrubber_slider")
            )

            // Total Duration
            Text(
                text = SubtitleSegment.formatTimestamp(project.durationMs),
                color = Color.White.copy(alpha = 0.6f),
                fontSize = 12.sp
            )
        }
    }
}

/**
 * Animated video canvas simulation providing realistic Douyin content motion
 */
@Composable
fun AnimatedSceneCanvas(
    category: String,
    isPlaying: Boolean,
    currentTimeMs: Long,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "scene_motion")
    val pulse by infiniteTransition.animateFloat(
        initialValue = 0.7f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        // Background subtle grid
        val gridStep = 40f
        var x = 0f
        while (x < w) {
            drawLine(
                color = Color.White.copy(alpha = 0.03f),
                start = Offset(x, 0f),
                end = Offset(x, h),
                strokeWidth = 1f
            )
            x += gridStep
        }

        // Animated theme graphics based on sample type
        when {
            category.contains("Trùng Khánh", ignoreCase = true) || category.contains("Lẩu", ignoreCase = true) -> {
                // Hotpot steam & fire circles
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(Color(0xFFFF3D00).copy(alpha = 0.25f * pulse), Color.Transparent),
                        center = Offset(w * 0.5f, h * 0.45f),
                        radius = w * 0.35f
                    ),
                    center = Offset(w * 0.5f, h * 0.45f),
                    radius = w * 0.35f
                )
            }
            category.contains("Smartphone", ignoreCase = true) || category.contains("Review", ignoreCase = true) -> {
                // Tech glowing cyber lines
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(StudioCyan.copy(alpha = 0.2f * pulse), Color.Transparent),
                        center = Offset(w * 0.5f, h * 0.45f),
                        radius = w * 0.4f
                    ),
                    center = Offset(w * 0.5f, h * 0.45f),
                    radius = w * 0.4f
                )
            }
            else -> {
                // Studio neon abstract
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(StudioPurple.copy(alpha = 0.25f * pulse), Color.Transparent),
                        center = Offset(w * 0.5f, h * 0.4f),
                        radius = w * 0.38f
                    ),
                    center = Offset(w * 0.5f, h * 0.4f),
                    radius = w * 0.38f
                )
            }
        }
    }
}
